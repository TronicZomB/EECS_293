Steve Paley
EECS 293 HW03

1. Go to Maze/ directory int command prompt
2. Type ant MazeJUnit