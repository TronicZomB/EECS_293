import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({ MazeCellJUnit.class, MazeRouteJUnit.class })
public class AllTests {

}
