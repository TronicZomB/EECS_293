Steve Paley
EECS 293 HW03

1. Go to HW04/ directory in the command prompt.
2. Type 'ant NewTests' to test the new methods added in assignment 4.
3. Type 'ant AllTests' to test all four JUnit test classes for MazeCell, MazeRoute, Maze, and the new tests for HW04.