Steve Paley
sjp78
EECS 293 HW05

1. Go to HW05/ directory in the command prompt.
2. Type 'ant NewTests' to test the new methods added in assignment 5.
3. Type 'ant AllTests' to test all five JUnit test classes for MazeCell, MazeRoute, Maze, HW04Tests, and the newest HW05 Tests.